Team 47 -- Milestone 3 final report

Main LaTeX file: main.tex
Compile with pdfLaTeX twice (no BibTeX step is required), or upload this entire
folder as a ZIP to Overleaf and select main.tex as the main document.
Keep Sections/, chapters/, References/ and Figures/ beside main.tex.

This package contains the report source and supplied MATLAB figures.
The computational source, experiment data and narrated demonstration are separate
submission deliverables. This report does not imply that a video is included.

The provided GUC format and team details were adapted for Milestone 3.
No unsigned originality declaration or placeholder acknowledgments are included.
Literature claims were restricted to verified sources. Results tables are generated
from the frozen final_v1 CSV summaries; no new optimization runs were substituted.
